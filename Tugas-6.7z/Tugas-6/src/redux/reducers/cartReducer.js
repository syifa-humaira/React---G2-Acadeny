import Item1 from '../../images/gambar1.jpg'
import Item2 from '../../images/gambar2.jpg'
import Item3 from '../../images/gambar3.jpg'
import Item4 from '../../images/gambar4.jpg'
import Item5 from '../../images/gambar5.jpg'
import Item6 from '../../images/gambar6.jpg'
import Item7 from '../../images/gambar7.jpg'
import Item8 from '../../images/gambar8.jpg'
import Item9 from '../../images/gambar9.jpg'

import { ADD_TO_CART,REMOVE_ITEM,SUB_QUANTITY,ADD_QUANTITY,ADD_DISCOUNT, SUB_DISCOUNT } from '../actions/constans'


const initState = {
    items: [
        {id:1,title:'True Water', desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ex.", price:2500000,img:Item1},
        {id:2,title:'Mahalo', desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ex.", price:310000,img: Item2},
        {id:3,title:'LOREAL', desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ex.",price:420000,img: Item3},
        {id:4,title:'Nature Republic Iceland', desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ex.", price:180000,img:Item4},
        {id:5,title:'Nature Republic', desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ex.", price:1600000,img: Item5},
        {id:6,title:'ETUDE Moisfull', desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ex.",price:320000,img: Item6},
        {id:7,title:'Klairs', desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ex.",price:650000,img: Item7},
        {id:8,title:'Miracle Age', desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ex.",price:250000,img: Item8},
        {id:9,title:'Laneige', desc: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ex.",price:1150000,img: Item9}

    ],
    addedItems:[],
    total: 0

}

const cartReducer= (state = initState,action)=>{
   
    if(action.type === ADD_TO_CART){
        let addedItem = state.items.find(item=> item.id === action.id)
         let existed_item= state.addedItems.find(item=> action.id === item.id)
         if(existed_item)
         {
            addedItem.quantity += 1 
             return{
                ...state,
                 total: state.total + addedItem.price 
                  }
        }
         else{
            addedItem.quantity = 1;
            let newTotal = state.total + addedItem.price 
            
            return{
                ...state,
                addedItems: [...state.addedItems, addedItem],
                total : newTotal
            }
            
        }
    }
    if(action.type === REMOVE_ITEM){
        let itemToRemove= state.addedItems.find(item=> action.id === item.id)
        let new_items = state.addedItems.filter(item=> action.id !== item.id)
        
        let newTotal = state.total - (itemToRemove.price * itemToRemove.quantity )
        console.log(itemToRemove)
        return{
            ...state,
            addedItems: new_items,
            total: newTotal
        }
    }

    if(action.type=== ADD_QUANTITY){
         let addedItem = state.items.find(item=> item.id === action.id)
          addedItem.quantity += 1 
          let newTotal = state.total + addedItem.price
          return{
              ...state,
              total: newTotal
          }
    }
    
    if(action.type=== SUB_QUANTITY){  
        let addedItem = state.items.find(item=> item.id === action.id) 
        if(addedItem.quantity === 1){
            let new_items = state.addedItems.filter(item=>item.id !== action.id)
            let newTotal = state.total - addedItem.price
            return{
                ...state,
                addedItems: new_items,
                total: newTotal
            }
        }
        else {
            addedItem.quantity -= 1
            let newTotal = state.total - addedItem.price
            return{
                ...state,
                total: newTotal
            }
        }
        
    }

    if(action.type=== ADD_DISCOUNT){
          return{
              ...state,
              total: state.total - 50000
          }
    }

    if(action.type=== SUB_DISCOUNT
        ){
        return{
            ...state,
            total: state.total + 50000
        }
  }
    
  else{
    return state
    }
    
}

export default cartReducer
