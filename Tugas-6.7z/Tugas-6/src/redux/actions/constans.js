export const ADD_TO_CART = 'ADD_TO_CART';
export const REMOVE_ITEM = 'REMOVE_ITEM';
export const SUB_QUANTITY = 'SUB_QUANTITY';
export const ADD_QUANTITY = 'ADD_QUANTITY';
export const ADD_DISCOUNT = 'ADD_DISCOUNT';
export const SUB_DISCOUNT = 'SUB_DISCOUNT';

