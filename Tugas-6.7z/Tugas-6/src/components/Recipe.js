import React, { Component } from 'react'
import { connect } from 'react-redux'
import { addDiscount, subtractDiscount } from '../redux/actions';
import Button from '@material-ui/core/Button'


class Recipe extends Component{
    
    componentWillUnmount() {
         if(this.refs.discount.checked)
              this.props.subtractDiscount()
    }

    handleChecked = (e)=>{
        if(e.target.checked){
            this.props.addDiscount();
        }
        else{
            this.props.subtractDiscount();
        }
    }

    render(){
  
        return(
            <div className="container">
                <div className="collection">
                    <li className="collection-item">
                            <label>
                                <input type="checkbox" ref="discount" onChange= {this.handleChecked} />
                                <span>Discount Rp.50,000</span>
                            </label>
                        </li>
                        <li className="collection-item"><b>Total: Rp. {this.props.total.toLocaleString()} </b></li>
                    </div>
                    <div className="checkout">
                        <Button variant="contained" color="secondary">CHECKOUT</Button>
                    </div>
                 </div>
        )
    }
}

const mapStateToProps = (state)=>{
    return{
        addedItems: state.addedItems,
        total: state.total
    }
}

const mapDispatchToProps = (dispatch)=>{
    return{
        addDiscount: ()=>{dispatch(addDiscount())},
        subtractDiscount: ()=>{dispatch(subtractDiscount())}
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Recipe)
