import React from "react";
import { Link } from "react-router-dom";
import {connect} from 'react-redux'

import Badge from "@material-ui/core/Badge";
import { withStyles } from "@material-ui/core/styles";
import IconButton from "@material-ui/core/IconButton";
import ShoppingCartIcon from "@material-ui/icons/ShoppingCart";

const StyledBadge = withStyles((theme) => ({
  badge: {
    right: -3,
    top: 13,
    border: `2px solid ${theme.palette.background.paper}`,
    padding: "0 4px",
  },
}))(Badge);

const Navbar = (props) => {

  return (
    <nav className="nav-wrapper">
      <div className="container">
        <Link to="/" className="brand-logo">
          CHARIVA BEAUTY
        </Link>

        <ul className="right">
          <li>
            <Link to="/">HOME</Link>
          </li>
          <li>
            <Link to="/cart">
              <IconButton aria-label="cart">
                <StyledBadge badgeContent={props.cart.length} color="primary">
                  <ShoppingCartIcon />
                </StyledBadge>
              </IconButton>
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

const mapStateToProps = (state) => {
    return {
        cart: state.addedItems
    }
}

export default connect(mapStateToProps)(Navbar);