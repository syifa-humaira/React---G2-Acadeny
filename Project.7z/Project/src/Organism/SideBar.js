import React from 'react';
import { withStyles } from "@material-ui/core/styles"; import Drawer from '@material-ui/core/Drawer';
import CssBaseline from '@material-ui/core/CssBaseline';

import List from 'Molecule'

const drawerWidth = 240;

const styles = theme => ({
  root: {
    display:'flex',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
  },
  drawerPaper: {
    width: drawerWidth,
    background: 'tan',
    color:'black'
  },
  drawerHeader: {
    display: 'flex',
    alignItems: 'center',
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
    justifyContent: 'flex-end',
    background:'theme.'
  },
});

class SideNav extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

    };
  }

  onSetSidebarOpen(open) {
    this.setState({ sidebarOpen: open });
  }

  render() {
    const { classes } = this.props;

    return (
      <div className={classes.root}>
        <CssBaseline />
        <Drawer
          className={classes.drawer}
          variant="persistent"
          anchor="left"
          open={this.onSetSidebarOpen.bind(this)}
          classes={{
            paper: classes.drawerPaper,
          }}
        >
          <List />
        </Drawer>
      </div>
    );
  }
}


export default withStyles(styles, { withTheme: true })(SideNav)
