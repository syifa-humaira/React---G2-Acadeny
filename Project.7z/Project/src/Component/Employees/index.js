import React, { Component } from 'react';
import styles from './App.module.css';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      users: [],
      total: 0,
      per_page: 3,
      current_page: 1,
      pageNumber: 1,
      total_page: 0
    }
  }

  componentDidMount() {
    this.fetchUsers(1);
  }


  fetchUsers = async (pageNumber) => {
    await fetch(`https://reqres.in/api/users?page=${pageNumber}&per_page=${this.state.per_page}`)
      .then(response => response.json())
      .then(data => {
        this.setState({
          users: data.data,
          total: data.total,
          per_page: data.per_page,
          current_page: data.page,
          total_page: data.total_pages
        })
      });
  }


  render() {

    let users, renderPageNumbers;

    if (this.state.users !== null) {
      users = this.state.users.map(user => (
        <tr key={user.id}>
          <td>{user.id}</td>
          <td>{user.first_name}</td>
          <td>{user.last_name}</td>
          <td>{user.email}</td>
          <td><img src={user.avatar} alt="photo" /></td>
        </tr>
      ));
    }

    const pageNumbers = [];
    if (this.state.total !== null) {
      for (let i = 1; i <= Math.ceil(this.state.total / this.state.per_page); i++) {
        pageNumbers.push(i);
      }


      renderPageNumbers = pageNumbers.map(number => {
        let classes = this.state.current_page === number ? styles.active : '';

        return (
          <span key={number} className={classes} onClick={() => this.fetchUsers(number)}>{number}</span>
        );
      });
    }

    const { current_page } = this.state

    const prev = current_page === 1
    const next = current_page === 4

    return (


      <div className={styles.app}>

        <table className={styles.table}>
          <thead>
            <tr>
              <th>No.</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Photo</th>
            </tr>
          </thead>
          <tbody>
            {users}
          </tbody>
        </table>


        <div className={styles.pagination}>
          <button disabled={prev} onClick={() => this.fetchUsers(current_page - 1)}>&laquo;</button>
          {renderPageNumbers}
          <button disabled={next} onClick={() => this.fetchUsers(current_page + 1)}>&raquo;</button>
        </div>

      </div>
    );
  }

}

export default App