import React from "react";

const Dashboard = props => {
  return <div>Dashboard</div>;
};

export default Dashboard;
