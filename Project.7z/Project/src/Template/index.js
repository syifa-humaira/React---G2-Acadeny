import React from "react";
import Sidebar from "react-sidebar";
import List from 'Molecule'

import CssBaseline from '@material-ui/core/CssBaseline';
import MenuIcon from '@material-ui/icons/Menu';
import IconButton from '@material-ui/core/IconButton';

class SideNav extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      sidebarOpen: true,

    };
    this.onSetSidebarOpen = this.onSetSidebarOpen.bind(this);
  }

  onSetSidebarOpen(open) {
    this.setState({ sidebarOpen: open });
  }

  render() {

    return (
      <div>
        <CssBaseline />
        <Sidebar
          sidebar={<b>Sidebar content</b>}
          open={this.state.sidebarOpen}
          onSetOpen={this.onSetSidebarOpen}
          styles={{ sidebar: { background: "black", padding: "40px", zIndex:"1"}}
        }
        >
          <IconButton onClick={() => this.onSetSidebarOpen(true)}>
            <MenuIcon />
          </IconButton>
        <List />
        </Sidebar>
      </div>
    );
  }
}

export default SideNav;