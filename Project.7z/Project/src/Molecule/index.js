import React from 'react'
import { BrowserRouter, Route, Switch, Link } from 'react-router-dom'

import { makeStyles } from "@material-ui/core/styles"
import {
    List, ListItem,
    ListItemIcon, ListItemText, Container
} from '@material-ui/core'

import Dashboard from '@material-ui/icons/Dashboard';
import Employees from '@material-ui/icons/People';
import About from '@material-ui/icons/Book';
import Contact from '@material-ui/icons/ContactSupport';
import PageContact from 'Component/Contact'

const useStyles = makeStyles((theme) => ({
    link: {
        textDecoration: 'none',
        color: theme.palette.text.primary
    }
}))

function ListMenu() {
    const classes = useStyles();

    return (
        <BrowserRouter>
            <div >
                <List>
                    <Link to="/" className={classes.link}>
                        <ListItem button>
                            <ListItemIcon>
                                <Dashboard />
                            </ListItemIcon>
                            <ListItemText primary="Dashboard" />
                        </ListItem>
                    </Link>
                    <Link to="/employees" className={classes.link}>
                        <ListItem button>
                            <ListItemIcon>
                                <Employees />
                            </ListItemIcon>
                            <ListItemText primary="Employess" />
                        </ListItem>
                    </Link>
                    <Link to="/about" className={classes.link}>
                        <ListItem button>
                            <ListItemIcon>
                                <About />
                            </ListItemIcon>
                            <ListItemText primary="About" />
                        </ListItem>
                    </Link>
                    <Link to="/contact" className={classes.link}>
                        <ListItem button>
                            <ListItemIcon>
                                <Contact />
                            </ListItemIcon>
                            <ListItemText primary="Contact" />
                        </ListItem>
                    </Link>
                </List>
            </div>
            <Switch>
                <Route exact path="/" >
                    <Container>
                    </Container>
                </ Route>
                <Route exact path="/employees" >
                    <Container>
                    </Container>
                </ Route>
                <Route exact path="/about" >
                    <Container>
                    </Container>
                </ Route>
                <Route exact path="/contact" >
                    <Container>
                        <PageContact />
                    </Container>
                </ Route>
            </Switch>
        </BrowserRouter>
    );
}

export default ListMenu