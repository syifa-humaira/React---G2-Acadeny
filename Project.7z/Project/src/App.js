// import React from 'react'

// import Dashboard from 'Component/Dashboard'
// import Employees from 'Component/Employees'
// import About from 'Component/About'
// import Contact from 'Component/Contact'

// function App() {
//   return (
    
//   )
// }

// export default App